-- MySQL dump 10.11
--
-- Host: localhost    Database: rosenich_losttoys
-- ------------------------------------------------------
-- Server version	5.0.92-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `item_id` int(11) NOT NULL auto_increment,
  `item_type` varchar(40) NOT NULL,
  `location_lost` varchar(40) NOT NULL,
  `date_lost` date NOT NULL,
  `circumstances` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `colour` varchar(30) NOT NULL,
  `features` varchar(80) NOT NULL,
  `image` varchar(255) NOT NULL,
  `owns` int(11) default NULL,
  PRIMARY KEY  (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (1,'Stuffed monkey','Newport City centre','2011-03-19','Dropped by my child in town. The last shops we went into were Marks & Spencer and Boots. We were parked in the Market car park','Dark blue body with lighter blue patches on face. Curly tail.','Blue','Left ear has been re-stitched','',15),(2,'Teddy bear','Elswick Park, Newcastle','2011-02-12','Lost somewhere around Elswick park.','Large teddy with floppy arms and legs. Mid-brown with lighter brown belly and face. Black eyes and stitching.','Brown','Small stain on right arm','',NULL),(3,'Beanie horse','Fisher\'s Farm Park, West Sussex','2011-03-02','Lost on a school trip. Possibly left in the cafe or left on the tractor ride.','Light brown with black hoofs and a black mane.','Brown','No tail','',NULL),(4,'Panda bear toy','Cardiff Central train station','2011-02-20','I was rushing with my child to catch the train. The toy must have fallen out of my bag somewhere in the station.','Black and white stuffed panda toy. Well loved. Approx 15cm tall.','Black and white','None','',NULL),(5,'Stuffed rabbit','Truro, Cornwall','2011-01-29','Lost at the end of our holiday in Cornwall. Possibly left somewhere in Carnon Downs Caravan Park.','Dark brown and white.','Brown and white.','Hole at the top of the left ear','',NULL),(6,'Beanie cat toy','Tate art gallery, London','2011-03-16','Lost on a school trip.','Light grey with dark grey stripes. Red TY tag attached to ear.','Grey','S in red pen on the tag.','',NULL),(7,'Stuffed toy','Bristol','2011-03-22','Shopping in town','Fluffy bird','Yellow','Orange beak','',0),(8,'Beanie toy','Bath','2011-03-22','Spending the day siteseeing in Bath, visited the Royal Crescent and Fashion museum','Smallish beanie toy, red tag attached to one ear','Black','None.','',0),(13,'Plastic toy','UWE, Bristol','2011-03-23','My baby dropped the toy during a visit into the University of the West of England, Bristol','Plastic rattle toy red and white','Red','None','',10),(27,'Soft toy','Paignton Zoo','2011-03-22','Lost at the zoo','Lion toy with fluffy man','Yellow brown','None','',24),(29,'Mobile phone toy','Bath town centre','2011-03-21','Lost in Bath at some point during the day','Toy shaped like a mobile phone. Silver buttons that play sounds when you press them.','Black and silver','conspicuous @ symbol','',26),(30,'Plush toy','London Zoo','2011-02-22','Lost a koala soft toy during a trip to London Zoo','A koala toy, very soft and fluffy. Shades of grey with a black nose and eyes.','Grey','Name Lucy is written on the tag attached to one of its feet','  ',27),(31,'Plastic toy','Bristol Zoo','2011-03-09','Lost at some point during the day at a trip to the zoo','Black rabbit toy','Black','None','',28),(32,'Plush toy','Chester Zoo','2011-04-05','Lost at the zoo, possibly left somewhere after we stopped for lunch','Soft giraffe toy purchased at the zoo','Yellow brown','Left in a bag with a notebook and disposable camera','',29);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owner`
--

DROP TABLE IF EXISTS `owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owner` (
  `owner_id` int(11) NOT NULL auto_increment,
  `fname` varchar(40) NOT NULL,
  `sname` varchar(40) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY  (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owner`
--

LOCK TABLES `owner` WRITE;
/*!40000 ALTER TABLE `owner` DISABLE KEYS */;
INSERT INTO `owner` VALUES (4,'Sarah','Young','sarah.young@gmail.com'),(5,'Barney','Jones','barney.jones@googlemail.com'),(6,'Joe','Bloggs','joseph.bloggs@hotmail.com'),(7,'Austin','Reed','austin@reed.co.uk'),(8,'Elizabeth','Bennett','lizziebennett@gmail.com'),(10,'Jenny','Baker','jenbaker@live.com'),(13,'Ben','Nolan','b_nolan@live.uk'),(15,'Rebecca','Harrison','becky@harrison.net'),(16,'Roland','Myers','roland.myers@live.com'),(24,'Rose','Nichols','rose2.nichols@live.uwe.ac.uk'),(26,'Anthony','Kelly','ant_kelly2@googlemail.com'),(27,'Harrison','Jones','oldharryjones@hotmail.com'),(28,'Tamara','Bagshawe','tam.bagshawe@live.com'),(29,'Kate','Fforde','kate@fforde.com');
/*!40000 ALTER TABLE `owner` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-28 12:44:48
