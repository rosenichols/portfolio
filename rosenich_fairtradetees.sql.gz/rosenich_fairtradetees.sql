-- MySQL dump 10.11
--
-- Host: localhost    Database: rosenich_fairtradetees
-- ------------------------------------------------------
-- Server version	5.0.92-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `addr_id` int(11) NOT NULL auto_increment,
  `type` varchar(8) NOT NULL,
  `addr1` varchar(30) NOT NULL,
  `addr2` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `county` varchar(30) NOT NULL,
  `postcode` varchar(8) NOT NULL,
  `user_id` int(5) NOT NULL,
  PRIMARY KEY  (`addr_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,'Billing','Hillfield','Ringland Circle','Newport','S Wales','NP19 9PL',1),(2,'Billing','Potter Residence','Potter Street','Potterville','UK','PO19 9OP',1),(3,'Billing','Potter House','Potter Lane','Potteridge','UK','PO14 2PL',4),(4,'Billing','Potter House','Potter Lane','Potterville','UK','CF10 4PF',4),(5,'Billing','Potter Residence','Potter Lane','Potterville','Potteridge','PO46 6TT',5);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL auto_increment,
  `category` varchar(20) NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Tunic tops'),(2,'Tank tops'),(3,'T-shirts'),(4,'Ruched tops'),(5,'Halter tops'),(6,'Geek chic');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `item_id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `brand` varchar(30) NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `description` text NOT NULL,
  `colour` varchar(20) NOT NULL,
  `stock` int(3) NOT NULL,
  `image_thumb` varchar(50) NOT NULL,
  `image_full` varchar(50) NOT NULL,
  `cat_id` int(11) default NULL,
  PRIMARY KEY  (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (1,'Asymmetric silk tunic','Lionnet','845.00','A draped black and cream silk sash adds elegant fluidity to Lionnet\'s mushroom silk asymmetric tunic. Wear this cool color-block piece with leggings and kitten heels for understated cocktail elegance.','Cream',12,'asymmetric_tunic.png','asymmetric_tunic_full.png',1),(2,'Striped fine-knit cashmere tank','Lumet','230.00','Lumet\'s light-blue and white striped cashmere tank will instantly pep up a simple weekend look.','Blue',44,'blue_stripe_vest.png','blue_stripe_vest_full.png',2),(3,'Halterneck body-con top','Ervé','59.00','Ervé\'s body-con halterneck top is a fresh take on the label\'s signature style. Wear it on the summer party circuit with beige sandals and a cobalt clutch.','Blue',27,'blue_v_halter.png','blue_v_halter_full.png',5),(4,'Split-sleeve printed silk tunic','Buonito','505.00','Alessandro Buonito\'s split-sleeve pink, brown and pink silk tunic is a brilliant way to tap into this season\'s bold prints. Pair it with skinny jeans to offset a voluminous silhouette.','Brown',70,'brown_pink_tunic.png','brown_pink_tunic_full.png',1),(5,'Burgundy tunic','Two Vintage','400.00','Two Vintage\'s maroon 1930s silk-crepe halterneck tunic is a glamorous evening choice. This piece has been lovingly restored by Two Vintage, any imperfections which may have occurred through the years only add to its individuality.','Red',2,'burgundy_tunic.png','burgundy_tunic_full.png',1),(6,'Green ruched halterneck top','Z Studio','75.00','This halter top is sexy but in a very subtle way. The design of this top shows off the shoulders and creates flattering curves with horizontal shirring that runs from empire to hem, while criss-crossing adjustable straps anchor the fabric that drapes softly over the bust. The Tencel & wool jersey fabric is decadently soft with a lighter weight that’s ideal for year-round wear','Green',58,'green_ruched_halter.png','green_ruched_halter_full.png',4),(7,'Plain scoop neck tee','Originals','24.99','These scoop neck cotton-jersey tees are the perfect foundation to trans-seasonal looks. Use as a base for layering in AW, and wear on its own in SS.','Blue',180,'navy_scoop_tee.png','navy_scoop_tee_full.png',3),(8,'Modal and silk blend tee','Kline','70.00','Update transitional basics with Kline\'s simple orange modal and silk-blend tee. Layer it over your favourite jeans now or team it with a mini skirt and wedge sandals','Orange',84,'orange_tee.png','orange_tee_full.png',3),(9,'V neck camisole','Lili','150.00','Lili\'s silk racer-back camisole with side lace detail will make a chic accompaniment to tailored shorts. Add flat pumps and a structured bag for off-duty city days','Red',59,'red_v_cami.png','red_v_cami_full.png',2),(10,'Turquoise Silk Tunic','Opals','170.00','This brightly coloured silk tunic is a chic pull-on-and-go vacation piece. Wear it with light-brown leather sandals and stacked gold bangles for Balearic boho luxury.','Blue',38,'teal_tunic.png','teal_tunic_full.png',1),(11,'Pure cotton halter top','Lissoni','49.99','Nothing says cool-weather glamour like a Lissoni creation - and this pretty lightweight halterneck top is the perfect way to work it on vacation. Wear it with cropped denim and bold gold jewelry for destination dressing at its best.','Yellow',98,'yellow_halter.png','yellow_halter_full.png',5),(12,'Printed jersey tunic','Tucci','420.00','Tucci\'s multicolored abstract-print jersey tunic will add a chic burst of colour to your holiday wardrobe. Keep cool in the summer heat by teaming it with white mini shorts and bead-embellished sandals.','Blue',35,'swirl_top.png','swirl_top_full.png',1),(13,'Cotton tank','Rory','70.00','This coral cotton tank is an effortlessly cool summer style. Wear it to pep up taupe chinos and stone wooden wedges.','Orange',68,'coral_vest.png','coral_vest_full.png',2),(14,'Jersey and silk blend tank','Suzanna','50.00','Show your geek chic credentials with this cool urban tank. Slip it on with black skinny jeans and statement black platforms for a downtown look with attitude.','Red',205,'red_geek.png','red_geek_full.png',6),(15,'Striped tunic top','Tenby','190.00','This striking tunic top combines modern stripes with an undying love for Google. Team with skinny jeans for a chic day ensemble.','Blue',94,'geek_striped.png','geek_striped_full.png',6),(16,'Draped modal top','Kingly','160.00','A draped scarf detail gives Kingly\'s sheer teal modal tank an elegant evening edge. Complete the look with tailored trousers and statement gold jewellery.','Blue',130,'blue_draped.png','blue_draped_full.png',4),(17,'Cotton geek tee','Ophelia','55.00','Ophelia updates the classic white cotton tee with super cool geek logo and a scoop neck. Wear this sheer fine-knit basic off duty with cropped skinny pants and dark-brown accessories.','White',420,'white_geek.png','white_geek_full.png',6),(18,'Scoop neck cotton jersey tee','Persephone','50.00','No capsule wardrobe is complete without a classic fail whale cotton-jersey t-shirt like this one from Persephone. Tuck it into skinny cargo pants and elevate the look with wedges for relaxed downtown cool.','Blue',239,'failwhale_tee.png','failwhale_tee_full.png',6),(19,'Awesome tank','Ichigo','72.00','Easy-chic basics like Ichigo\'s grey and awesome jersey tank are the cornerstone of every stylish wardrobe. Wear it with track pants and heels for effortless off-duty cool. ','Grey',374,'awesome_vest.png','awesome_vest_full.png',6),(20,'Print silk tunic top','Bennett','580.00','An eye-catching print makes Bennett\'s blue silk blouse a glamorous cocktail choice. Balance by teaming this luxe style with skinny leather pants and high-as-you-dare heels.','Blue',193,'pattern_tunic.png','pattern_tunic_full.png',1),(21,'HTML5 Cotton tee','Ichigo','135.00','Ichigo gives a simple white tee a stylish twist with chic HTML5 logo. Tuck this wear-with-anything piece into a neutral skirt, then finish the look with nude pumps and a cross-body bag.','White',145,'html5_tee.png','html5_tee_full.png',6),(22,'Signature silk binary top','Streets','195.00','Give minimalist cool a twist in this black sheer washed-silk binary detail top. Team it with big shorts and color-pop heels for refined new-season style.','Black',64,'black_binary.png','black_binary_full.png',6),(23,'Printed silk-chiffon top','Lacey','365.00','Invest in signature Lacey style with this bohemian-inspired multicolored silk-chiffon top. Team this sheer abstract-print piece with linen shorts and carry a rattan clutch to finish the look. ','Pink',356,'colourblock_tunic.png','colourblock_tunic_full.png',1),(24,'Cotton tank','Haruna','80.00','It\'s easy to make a on-trend color statement with Haruna\'s fuschia cotton tank. Team it with neutral-hued cotton shorts and buckle-embellished wedges for a cool weekend look.','Pink',937,'pink_vest.png','pink_vest_full.png',2);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_size`
--

DROP TABLE IF EXISTS `item_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_size` (
  `item_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  PRIMARY KEY  (`size_id`,`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_size`
--

LOCK TABLES `item_size` WRITE;
/*!40000 ALTER TABLE `item_size` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `order_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `card_digits` varchar(4) NOT NULL,
  PRIMARY KEY  (`order_id`,`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,4,'7777'),(2,6,'1111'),(3,7,'1111'),(4,8,'1111'),(5,9,'1111');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_item` (
  `order_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY  (`item_id`,`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
INSERT INTO `order_item` VALUES (0,0,0),(0,1,1),(0,15,1),(0,8,1),(0,11,2),(0,2,3),(4,11,2),(4,2,3),(5,11,2),(5,2,3),(2,18,1),(2,23,1),(3,18,1),(3,23,1);
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `size`
--

DROP TABLE IF EXISTS `size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `size` (
  `size_id` int(11) NOT NULL auto_increment,
  `size` varchar(2) NOT NULL,
  PRIMARY KEY  (`size_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `size`
--

LOCK TABLES `size` WRITE;
/*!40000 ALTER TABLE `size` DISABLE KEYS */;
INSERT INTO `size` VALUES (5,'XL'),(4,'L'),(3,'M'),(1,'XS'),(2,'S');
/*!40000 ALTER TABLE `size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL auto_increment,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` char(32) default NULL,
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Rose','Nichols','rose@rosenichols.co.uk','password'),(2,'Joel','Nichols','joel@cbm.com','password'),(3,'Rose','Nichols','rose_nichols@hotmail.com','password'),(4,'Harry','Potter','hpotter@live.com','password'),(5,'Wilfred','Elphick','wilf@elphick.com',''),(6,'Harry','Potter','h.potter@hp.com',''),(7,'Harry','Potter','harry@potters.net',''),(8,'Harry','Potter','h.potter@hotmail.com',''),(9,'Harry','Potter','harry@potter.com','');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_item`
--

DROP TABLE IF EXISTS `user_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_item` (
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY  (`item_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_item`
--

LOCK TABLES `user_item` WRITE;
/*!40000 ALTER TABLE `user_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-28 12:44:48
