-- MySQL dump 10.13  Distrib 5.5.37, for Linux (x86_64)
--
-- Host: localhost    Database: rosenich_portfolio
-- ------------------------------------------------------
-- Server version	5.5.37-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `atwd_currconv`
--

DROP TABLE IF EXISTS `atwd_currconv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atwd_currconv` (
  `code` varchar(3) NOT NULL,
  `rate` float NOT NULL,
  `curr_name` varchar(70) NOT NULL,
  `countries` text NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atwd_currconv`
--

LOCK TABLES `atwd_currconv` WRITE;
/*!40000 ALTER TABLE `atwd_currconv` DISABLE KEYS */;
INSERT INTO `atwd_currconv` VALUES ('ZMK',5093.55,'Zambian kwacha','Zambia','2012-02-05 16:32:00'),('ZAR',7.7824,'South African rand','South Africa, Swaziland','2012-02-16 22:18:52'),('YER',218.75,'Yemeni rial','Yemen','2012-02-04 17:34:10'),('XPF',92.0698,'CFP franc','New Caledonia','2012-02-04 17:34:10'),('XOF',509.435,'West African CFA franc','Guinea-Bissau','2012-02-04 17:34:10'),('XCD',2.7,'East Caribbean dollar','Dominica','2012-02-04 17:34:10'),('XAF',507.75,'Central African CFA franc','Cameroon','2012-02-04 17:34:10'),('WST',2.2899,'Samoan tala','Samoa','2012-02-04 17:37:12'),('VUV',93.8,'Vanuatu vatu','Vanuatu','2012-02-04 17:34:10'),('VND',20900,'Vietnamese dong','Vietnam','2012-02-04 17:37:12'),('VEF',4.29469,'Venezuelan bolivar','Venezuela','2012-02-04 17:37:12'),('UZS',1808.17,'Uzbekistani som','Uzbekistan','2012-02-04 17:34:10'),('UYU',19.605,'Uruguayan peso','Uruguay','2012-02-04 17:34:10'),('USD',1,'United States dollar','America (United States), American Samoa, British Indian Ocean Territory, British Virgin Islands, East Timor, Ecuador, El Salvador, Guam, Johnson, Marshall Islands, Micronesia, Midway Islands, Navassa, Northern Mariana Islands, Palau, Panama, Puerto Rico, Turks and Caicos Islands, United States, Virgin Islands, Wake Island','2012-02-04 17:34:10'),('UGX',2363.8,'Ugandan shilling','Uganda','2012-02-04 17:34:10'),('UAH',8.04375,'Ukrainian hryvnia','Ukraine','2012-02-04 17:34:10'),('TZS',1597.25,'Tanzanian shilling','Tanzania','2012-02-04 17:34:10'),('TWD',29.9325,'New Taiwan dollar','Taiwan (Republic of China)','2012-02-04 17:34:10'),('TTD',6.36,'Trinidad and Tobago dollar','Trinidad and Tobago','2012-02-04 17:34:10'),('TRY',1.82945,'Turkish lira','Northern Cyprus','2012-02-04 17:34:10'),('TOP',1.6952,'Tongan pa\'anga','Tonga','2012-02-04 17:38:58'),('TND',1.51475,'Tunisian dinar','Tunisia','2012-02-04 17:34:10'),('THB',31.61,'Thai baht','Thailand','2012-02-04 17:34:10'),('SZL',8.03855,'Swazi lilangeni','Swaziland','2012-02-04 17:34:10'),('SYP',57.414,'Syrian pound','Syria','2012-02-04 17:34:10'),('SVC',8.7475,'Salvadoran colon','El Salvador','2012-02-04 17:38:58'),('STD',18930,'Sao Tome and Principe dobra','Sao Tome and Principe','2012-02-04 17:37:12'),('SOS',1629,'Somali shilling','Somalia','2012-02-18 12:39:04'),('SLL',4380,'Sierra Leonean leone','Sierra Leone','2012-02-18 12:39:04'),('SHP',0.64269,'Saint Helena pound','Saint Helena','2012-02-04 17:34:10'),('SGD',1.27093,'Singapore dollar','Brunei','2012-02-04 17:34:10'),('SEK',6.8308,'Swedish krona','Sweden','2012-02-04 17:34:10'),('SDG',2.68,'Sudanese pound','Sudan','2012-02-04 17:34:10'),('SCR',13.9615,'Seychellois rupee','Seychelles','2012-02-04 17:34:10'),('SBD',7.15044,'Solomon Islands dollar','Solomon Islands','2012-02-04 17:34:10'),('SAR',3.7503,'Saudi riyal','Saudi Arabia','2012-02-04 17:34:10'),('RWF',604.344,'Rwandan franc','Rwanda','2012-02-04 17:34:10'),('RUB',30.7483,'Russian ruble','South Ossetia','2012-02-04 17:34:10'),('RSD',81.4728,'Serbian dinar','Serbia','2012-02-04 17:34:10'),('RON',3.3098,'Romanian leu','Romania','2012-02-18 12:54:07'),('QAR',3.6408,'Qatari riyal','Qatar','2012-02-18 12:54:07'),('PYG',4675,'Paraguayan guarani','Paraguay','2012-02-04 17:37:12'),('PLN',3.1721,'Polish zloty','Poland','2012-02-22 22:19:52'),('PKR',90.16,'Pakistani rupee','Pakistan','2012-02-04 17:34:10'),('PHP',43.15,'Philippine peso','Philippines','2012-02-04 17:34:10'),('PGK',2.09538,'Papua New Guinean kina','Papua New Guinea','2012-02-04 17:34:10'),('PEN',2.6915,'Peruvian nuevo sol','Peru','2012-02-04 17:34:10'),('PAB',1,'Panamanian balboa','Panama','2012-02-04 17:34:10'),('OMR',0.38503,'Omani rial','Oman','2012-02-04 17:34:10'),('NZD',1.2063,'New Zealand dollar','New Zealand','2012-02-22 22:22:24'),('NPR',80.184,'Nepalese rupee','Nepal','2012-02-04 17:34:10'),('NOK',5.93128,'Norwegian krone','Norway','2012-02-04 17:34:10'),('NIO',23.036,'Nicaraguan cordoba','Nicaragua','2012-02-04 17:38:58'),('NGN',159.875,'Nigerian naira','Nigeria','2012-02-04 17:34:10'),('NAD',8.03855,'Namibian dollar','Namibia','2012-02-04 17:34:10'),('MYR',3.0435,'Malaysian ringgit','Malaysia','2012-02-18 12:26:17'),('MXN',12.7665,'Mexican peso','Mexico','2012-02-18 12:26:17'),('MWK',166.733,'Malawian kwacha','Malawi','2012-02-18 12:36:08'),('MVR',15.38,'Maldivian rufiyaa','Maldives','2012-02-18 12:36:08'),('MUR',29.3,'Mauritian rupee','Mauritius','2012-02-04 17:34:10'),('MRO',291,'Mauritanian ouguiya','Mauritania','2012-02-04 17:34:10'),('MOP',7.9869,'Macanese pataca','Macau','2012-02-22 22:23:46'),('MNT',1372.5,'Mongolian togrog','Mongolia','2012-02-04 17:38:58'),('MMK',6.43165,'Burmese kyat','Burma','2012-02-04 17:34:10'),('MKD',47.492,'Macedonian denar','Republic of Macedonia','2012-02-04 17:34:10'),('MDL',11.76,'Moldovan leu','Moldova','2012-02-04 17:34:10'),('MAD',8.59863,'Moroccan dirham','Morocco','2012-02-04 17:34:10'),('LYD',1.2566,'Libyan dinar','Libya','2012-02-04 17:34:10'),('LVL',0.5392,'Latvian lats','Latvia','2012-02-04 17:34:10'),('LTL',2.6681,'Lithuanian litas','Lithuania','2012-02-04 17:34:10'),('LSL',8.03855,'Lesotho loti','Lesotho','2012-02-04 17:34:10'),('LRD',73,'Liberian dollar','Liberia','2012-02-04 17:34:10'),('LKR',113.89,'Sri Lankan rupee','Sri Lanka','2012-02-04 17:34:10'),('LBP',1502,'Lebanese pound','Lebanon','2012-02-04 17:34:10'),('LAK',8008.5,'Lao kip','Laos','2012-02-04 17:34:10'),('KZT',148.58,'Kazakhstani tenge','Kazakhstan','2012-02-04 17:34:10'),('KYD',0.820001,'Cayman Islands dollar','Cayman Islands','2012-02-04 17:34:10'),('KWD',0.27871,'Kuwaiti dinar','Kuwait','2012-02-04 17:34:10'),('KRW',1125.95,'South Korean won','South Korea','2012-02-04 17:34:10'),('KPW',900,'North Korean won','North Korea','2012-02-04 17:34:10'),('KMF',379.575,'Comorian franc','Comoros','2012-02-04 17:34:10'),('KHR',4064,'Cambodian riel','Cambodia','2012-02-04 17:34:10'),('KGS',46.6512,'Kyrgyzstani som','Kyrgyzstan','2012-02-04 17:34:10'),('KES',85.6,'Kenyan shilling','Kenya','2012-02-04 17:34:10'),('JPY',107.206,'Japanese yen','Japan','2014-10-20 03:02:04'),('JOD',0.7086,'Jordanian dinar','Jordan','2012-02-04 17:34:10'),('JMD',86.275,'Jamaican dollar','Jamaica','2012-02-04 17:34:10'),('ISK',124.39,'Icelandic krona','Iceland','2012-02-04 17:38:58'),('IRR',11308.5,'Iranian rial','Iran','2012-02-04 17:34:10'),('IQD',1165,'Iraqi dinar','Iraq','2012-02-04 17:34:10'),('INR',50.1075,'Indian rupee','Bhutan','2012-02-04 17:34:10'),('ILS',3.78898,'Israeli new shekel','Israel','2012-02-04 17:34:10'),('IDR',8887.5,'Indonesian rupiah','Indonesia','2012-02-04 17:34:10'),('HUF',231.13,'Hungarian forint','Hungary','2012-02-04 17:34:10'),('HTG',40.3255,'Haitian gourde','Haiti','2012-02-04 17:34:10'),('HRK',5.85192,'Croatian kuna','Croatia','2012-02-04 17:34:10'),('HNL',19.06,'Honduran lempira','Honduras','2012-02-04 17:34:10'),('HKD',7.7571,'Hong Kong dollar','Hong Kong','2012-04-16 16:39:59'),('GYD',205.205,'Guyanese dollar','Guyana','2012-02-04 17:34:10'),('GTQ',7.805,'Guatemalan quetzal','Guatemala','2012-02-04 17:34:10'),('GNF',7225,'Guinean franc','Guinea','2012-02-04 17:34:10'),('GMD',30.51,'Gambian dalasi','The Gambia','2012-02-22 22:58:23'),('GIP',0.6382,'Gibraltar pound','Gibraltar','2012-02-22 22:58:23'),('GBP',0.6207,'British pound','Britain (United Kingdom), British Indian Ocean Territory, England (United Kingdom), Great Britain (United Kingdom), Scotland (United Kingdom), South Georgia, South Sandwich Islands, United Kingdom','2014-10-20 03:02:04'),('FKP',0.64269,'Falkland Islands pound','Falkland Islands','2012-02-04 17:34:10'),('FJD',1.7637,'Fijian dollar','Fiji','2012-02-22 22:26:37'),('EUR',0.7495,'Euro','Andorra, Austria, Azores, Balearic Islands, Belgium, Canary Islands, Cyprus, Dutch (Netherlands), Estonia, Europa Island, Finland, France, French Guiana, French Southern and Antarctic Lands, Germany, Greece, Guadeloupe, Holland (Netherlands), Holy See (Vatican City), Ireland, Italy, Juan de Nova, Luxembourg, Madeira Islands, Malta, Martinique, Mayotte, Monaco, Montenegro, Netherlands, Portugal, Reunion, Saint Pierre and Miquelon, Saint-Martin, San Marino, Slovakia, Slovenia, Spain, Vatican City','2013-01-11 14:06:54'),('ETB',17.4062,'Ethiopian birr','Ethiopia','2012-02-22 22:56:46'),('EGP',6.0375,'Egyptian pound','Egypt','2012-02-22 22:56:46'),('DZD',76.2591,'Algerian dinar','Algeria','2012-02-04 17:34:10'),('DOP',38.9,'Dominican peso','Dominican Republic','2012-02-18 12:30:09'),('DKK',5.6532,'Danish krone','Faroe Islands','2012-02-18 12:30:09'),('DJF',177.72,'Djiboutian franc','Djibouti','2012-02-04 17:34:10'),('CZK',19.621,'Czech koruna','Czech Republic','2012-02-04 17:34:10'),('CVE',85.2,'Cape Verdean escudo','Cape Verde','2012-02-04 17:34:10'),('CUP',1,'Cuban peso','Cuba','2012-02-22 22:45:56'),('CRC',513.62,'Costa Rican colon','Costa Rica','2012-02-04 17:37:12'),('COP',36688.3,'Colombian peso','Colombia','2012-02-07 14:49:58'),('CNY',6.3055,'Chinese yuan','China, Paracel Islands','2012-02-04 17:34:10'),('CLP',494.85,'Chilean peso','Chile','2012-02-04 17:34:10'),('CHF',0.9104,'Swiss franc','Liechtenstein, Switzerland','2012-02-22 22:55:15'),('CAD',1,'Canadian dollar','Canada','2012-02-22 22:55:15'),('BZD',1.9485,'Belize dollar','Belize','2012-02-04 17:34:10'),('BYR',8470,'Belarusian ruble','Belarus','2012-02-04 17:34:10'),('BWP',7.278,'Botswana pula','Botswana','2012-02-21 12:44:49'),('BTN',49.31,'Bhutanese ngultrum','Bhutan','2012-02-21 12:44:49'),('BSD',1,'Bahamian dollar','Bahamas','2012-02-21 12:41:42'),('BRL',1.7189,'Brazilian real','Brazil','2012-02-21 12:41:42'),('BOB',6.91,'Bolivian boliviano','Bolivia','2012-02-21 12:38:01'),('BND',1.2579,'Brunei dollar','Brunei','2012-02-21 12:38:01'),('BMD',1,'Bermudian dollar','Bermuda','2012-02-04 17:34:10'),('BIF',1385.3,'Burundian franc','Burundi','2012-02-04 17:34:10'),('BHD',0.377,'Bahraini dinar','Bahrain','2012-02-04 17:34:10'),('BGN',1.474,'Bulgarian lev','Bulgaria','2012-02-21 12:35:55'),('BDT',82.08,'Bangladeshi taka','Bangladesh','2012-02-21 12:35:55'),('BBD',2,'Barbadian dollar','Bajan (Barbados), Barbados','2012-02-21 12:32:18'),('AWG',1.7899,'Aruban florin','Aruba','2012-02-21 12:32:18'),('ARS',4.352,'Argentine peso','Argentina','2012-02-22 22:41:14'),('ALL',105.28,'Albanian lek','Albania','2012-02-22 22:38:57'),('AED',3.6732,'United Arab Emirates dirham','United Arab Emirates','2012-02-22 22:38:57'),('AUD',0.967,'Australian dollar','Ashmore and Cartier Islands, Australia, Christmas Island, Cocos (Keeling Islands, Coral Sea Islands, Kiribati, Nauru, Norfolk Island, Tuvalu','2012-04-16 14:26:10');
/*!40000 ALTER TABLE `atwd_currconv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_title` varchar(500) NOT NULL,
  `blog_text` text NOT NULL,
  `blog_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`blog_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
INSERT INTO `blog` VALUES (1,'Portfolio: Bowie Site','<p>The second assignment for the ‘Introduction to the Web’ first year module (timescale: Feb-March 2010) was to produce a David Bowie fan site featuring two of his albums and several pages showing the lyrics of songs.</p>\r\n\r\n<p>The first draft of my design wasn’t much good. I attempted to produce a perspective effect into the distance but it looked amateurish. I changed tack for the second attempt, keeping the typography but introducing a watercolour effect as a background. I was pleased with the effect created. I added drop shadows to try and retain some idea of perspective. My mum liked it so I thought that was probably a good sign.</p>\r\n\r\n<p>Once I had the design in place, putting the information in was pretty straightforward.</p>\r\n\r\n<p>If I were to redesign this website now, approximately a year on, I would definitely get rid of the text area which produces a scrollbar inside the main browser window, which may also gain a scrollbar on smaller resolution screens. Having this window-inside-a-window effect detracts from the usability of the site because it hides some of the content from the user, and may be counter intuitive for a user using the scroll wheel on their mouse if they are not hovering over the correct area of the screen.</p>\r\n\r\n<p>Furthermore, I can’t imagine how this would work on a touchscreen device such as an iPhone or iPad (other, non-Apple, alternatives are available) which is something I always take into account when I design websites now.</p>\r\n\r\n<p>One other point caused by this layout is that my CSS got a bit messy where I had to keep specifying individual attributes for the same element on multiple pages. I am better at keeping my CSS clean now.</p>','2010-11-07 17:50:00'),(2,'Portfolio: HelloGoodbye Band Site','<p>The second assignment for the first year module ‘Media Technologies’ (timeframe: Feb-March 2010) involved producing a promotional website for a famous person or group. I chose the American electro-pop band, HelloGoodbye.</p>\r\n\r\n<p>One of the first things I did was visit the official website of the band I had chosen, and the websites of related bands. I was able to gain a good idea of the kind of features that users of this type of site expect, and tried to evaluate the successfulness of each of the sites based on ease of use, clarity of navigation, style and user interaction. I made a note of what worked well, and of the common features and aimed to utilise this information in making my own site.</p>\r\n\r\n<p>I had a basic idea of what I wanted the site to look like; an idea which the end design bore only passing resemblance to. I knew this much: I wanted to use a slab typeface and I wanted a minimalistic design. That’s what I thought I wanted, anyway, though it was based only upon some notion of what theoretically might work. I tried out minimalism, but it just didn’t feel like it fit properly. Regardless, I marked up two variations on my minimal theme, and they both looked ok, but I couldn’t decide between one or the other layout. Eventually, I decided that I needed to go back to the drawing board, even as it was at a fairly late stage in the game, and come up with a new design. It turned out well this time, and I was happy with the new design.</p>\r\n\r\n<p>Building this new design, though, was an absolute nightmare.</p>\r\n\r\n<p>There were several requirements for the assignment in order to demonstrate use of various technologies and ability to use certain software packages.</p>\r\n\r\n<p>One of the requirements was to produce a composite video from at least three existing videos related to the artist. This was really good experience for me, having never really worked with this type of media before, and although I didn’t necessarily understand why certain things were happening during the process, I have a much better idea now of how I would go about the same task and improve upon the result. One of the problems I had was during the export process from Adobe Premiere Pro. I must have missed an option somewhere because the output was always of a reduced resolution from the way it played in the preview window in the software package itself.</p>\r\n\r\n<p>The video was to be displayed using Flash. I learnt that the correct address needs to be entered into the video properties panel each time the files are moved to a new location. I guess there’s probably some way to sort this out, but I couldn’t figure it.</p>\r\n\r\n<p>Another requirement was a flash based audio player which played 20 second clips of some of the artist’s songs. I relied upon the in-built functions in the Flash software to help me with this. I was given a snippet of code which handled the play and stop buttons based on user input, and I had to alter the code myself in order to differentiate the buttons for one song from the buttons for another song.</p>\r\n\r\n<p>A further requirement was the production of a logo, or another element of the site, in 3D using Maya. This was one requirement that I ran out of time to complete, although I did gain some experience using the software during a tutorial session for the module. I feel sure that, as with anything, given enough time I would be able to learn how to use the software to a reasonably competent degree. I guess I didn’t feel that it was a priority over some of the other requirements for the site. It seems to me rare that 3D is really implemented on the web at the moment.</p>\r\n\r\n<p>With the benefit of the time passed since this assignment (approximately a year) and the things I’ve learnt in the meantime, I can see that the site could be improved in many ways, but the site shows the skills that I had at the time. I find it useful to have this chronological set of examples to track my progress. I actually have examples of sites which I made years ago, long before I started to take web development seriously, and some of them are terrible, but again it’s a sign of progress. Maybe I’ll dig them out some time and post them here.</p>','2010-10-15 12:38:18'),(3,'Portfolio: EACC','<p>This was the second assignment for the first year module ‘Information Design.’</p>\r\n\r\n<p>Honestly, I left this assignment right until the last minute. It shows.</p>\r\n\r\n<p>The site is the main hub for of the fictional climate change action group, Erewhon Action on Climate Change. The site keeps members of the group informed about local and national climate change news, gives details of upcoming actions that the group will undertake, and provides non-member visitors to the site an opportunity to learn what the group does and become a member.</p>\r\n\r\n<p>In the time I had available, I produced the main frame of what I imagined the site would look like and a basic idea as to how it would function. The site lacks polish, and I could do a much better design now, but I don’t feel that it’s all bad.</p>','2010-11-20 13:54:33'),(4,'Portfolio: Hillfield Aviaries','<p>This website was produced for the first assignment in the second year module ‘Web Design Principles’ (timeframe: 8th Nov-9th Dec 2010).</p>\r\n\r\n<p>The most important purpose for this site, from an academic point of view, was to demonstrate competence of fluid layouts and ability to work from a comp image.</p>\r\n\r\n<p>Unfortunately, the two tutors taking this module couldn’t agree to what degree adherence to the comp image was necessary, resulting in one half of the year group staying strictly to the image, and the other half (my half) being given fairly much free rein to make improvements as we pleased. The topic of the site was up to each student to choose for themselves. I chose a topic that I am personally interested in, and more importantly, that I had enough images I could use for the required image gallery.</p>\r\n\r\n<p>(The following is an excerpt from the academic report I wrote about the site, so forgive me if I say some obvious things).</p>\r\n\r\n<p>I decided build the layout of my website using ems. I chose this method over a percentage based layout because it affords greater accuracy of dimensions, and over pixel based layouts because it affords greater flexibility. I was pleasantly surprised at how easy it was to implement an em based layout, however, I did discover several drawbacks along the way.</p>\r\n\r\n<p>In em based layouts, elements must have a height and width specified in order to scale. The problem with this is that, not being possible to specify height and width for background images, these do not scale with the rest of the site. As a result of this, I had to make the decision to discard several background images which served no purpose other than improving presentation. I made this decision in order to further the accessibility and flexibility of the site.</p>\r\n\r\n<p>I encountered a similar problem when specifying the dimensions of the main navigation bar links. The specified height and width applied to the container (in this case div elements) and not to the actual background images, meaning that when I specified these dimensions in terms of em, the size of the div increased, which in turn broke the presentation of the links. I considered the option of reverting to plain text links, which would be more flexible in terms of increasing in size, however I ultimately felt that the use of images improved the presentation significantly enough that they warranted their place on the site even without scaling. Furthermore, the links were still functional when the rest of the site scaled up. The same issue was encountered with the rollover effects of the thumbnail images on the gallery page, with the same outcome.</p>\r\n\r\n<p>I encountered a few issues also with making the website fluid. Text is forgiving of being pulled and pushed around, but images and secondary columns less so.</p>\r\n\r\n<p>The main problem I encountered was the main column dropping underneath the smaller left hand column when the page was resized. This was hugely annoying. I eventually found a solution on the internet which helped me. The solution was to create a fixed smaller column and use margins to push the main column across so that it sat alongside.</p>','2010-12-03 19:04:00');
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftt_address`
--

DROP TABLE IF EXISTS `ftt_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftt_address` (
  `addr_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(8) CHARACTER SET latin1 NOT NULL,
  `addr1` varchar(30) CHARACTER SET latin1 NOT NULL,
  `addr2` varchar(30) CHARACTER SET latin1 NOT NULL,
  `city` varchar(30) CHARACTER SET latin1 NOT NULL,
  `county` varchar(30) CHARACTER SET latin1 NOT NULL,
  `postcode` varchar(8) CHARACTER SET latin1 NOT NULL,
  `user_id` int(5) NOT NULL,
  PRIMARY KEY (`addr_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftt_address`
--

LOCK TABLES `ftt_address` WRITE;
/*!40000 ALTER TABLE `ftt_address` DISABLE KEYS */;
INSERT INTO `ftt_address` VALUES (1,'Billing','Hillfield','Ringland Circle','Newport','S Wales','NP19 9PL',1),(2,'Billing','Potter Residence','Potter Street','Potterville','UK','PO19 9OP',1),(3,'Billing','Potter House','Potter Lane','Potteridge','UK','PO14 2PL',4),(4,'Billing','Potter House','Potter Lane','Potterville','UK','CF10 4PF',4),(5,'Billing','Potter Residence','Potter Lane','Potterville','Potteridge','PO46 6TT',5),(6,'Billing','sjdh','shdh','hshffh','hffhfh','xhfxh',0),(7,'Billing','','','','','',0),(8,'Billing','','','','','',0),(9,'Billing','','','','','',0),(10,'Billing','','','','','',0),(11,'Billing','','','','','',0);
/*!40000 ALTER TABLE `ftt_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftt_category`
--

DROP TABLE IF EXISTS `ftt_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftt_category` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(20) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftt_category`
--

LOCK TABLES `ftt_category` WRITE;
/*!40000 ALTER TABLE `ftt_category` DISABLE KEYS */;
INSERT INTO `ftt_category` VALUES (1,'Tunic tops'),(2,'Tank tops'),(3,'T-shirts'),(4,'Ruched tops'),(5,'Halter tops'),(6,'Geek chic');
/*!40000 ALTER TABLE `ftt_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftt_item`
--

DROP TABLE IF EXISTS `ftt_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftt_item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `brand` varchar(30) CHARACTER SET latin1 NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `description` text CHARACTER SET latin1 NOT NULL,
  `colour` varchar(20) CHARACTER SET latin1 NOT NULL,
  `stock` int(3) NOT NULL,
  `image_thumb` varchar(50) CHARACTER SET latin1 NOT NULL,
  `image_full` varchar(50) CHARACTER SET latin1 NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftt_item`
--

LOCK TABLES `ftt_item` WRITE;
/*!40000 ALTER TABLE `ftt_item` DISABLE KEYS */;
INSERT INTO `ftt_item` VALUES (1,'Asymmetric silk tunic','Lionnet',845.00,'A draped black and cream silk sash adds elegant fluidity to Lionnet\'s mushroom silk asymmetric tunic. Wear this cool color-block piece with leggings and kitten heels for understated cocktail elegance.','Cream',12,'asymmetric_tunic.png','asymmetric_tunic_full.png',1),(2,'Striped fine-knit cashmere tank','Lumet',230.00,'Lumet\'s light-blue and white striped cashmere tank will instantly pep up a simple weekend look.','Blue',44,'blue_stripe_vest.png','blue_stripe_vest_full.png',2),(3,'Halterneck body-con top','Ervé',59.00,'Ervé\'s body-con halterneck top is a fresh take on the label\'s signature style. Wear it on the summer party circuit with beige sandals and a cobalt clutch.','Blue',27,'blue_v_halter.png','blue_v_halter_full.png',5),(4,'Split-sleeve printed silk tunic','Buonito',505.00,'Alessandro Buonito\'s split-sleeve pink, brown and pink silk tunic is a brilliant way to tap into this season\'s bold prints. Pair it with skinny jeans to offset a voluminous silhouette.','Brown',70,'brown_pink_tunic.png','brown_pink_tunic_full.png',1),(5,'Burgundy tunic','Two Vintage',400.00,'Two Vintage\'s maroon 1930s silk-crepe halterneck tunic is a glamorous evening choice. This piece has been lovingly restored by Two Vintage, any imperfections which may have occurred through the years only add to its individuality.','Red',2,'burgundy_tunic.png','burgundy_tunic_full.png',1),(6,'Green ruched halterneck top','Z Studio',75.00,'This halter top is sexy but in a very subtle way. The design of this top shows off the shoulders and creates flattering curves with horizontal shirring that runs from empire to hem, while criss-crossing adjustable straps anchor the fabric that drapes softly over the bust. The Tencel & wool jersey fabric is decadently soft with a lighter weight that’s ideal for year-round wear','Green',58,'green_ruched_halter.png','green_ruched_halter_full.png',4),(7,'Plain scoop neck tee','Originals',24.99,'These scoop neck cotton-jersey tees are the perfect foundation to trans-seasonal looks. Use as a base for layering in AW, and wear on its own in SS.','Blue',180,'navy_scoop_tee.png','navy_scoop_tee_full.png',3),(8,'Modal and silk blend tee','Kline',70.00,'Update transitional basics with Kline\'s simple orange modal and silk-blend tee. Layer it over your favourite jeans now or team it with a mini skirt and wedge sandals','Orange',84,'orange_tee.png','orange_tee_full.png',3),(9,'V neck camisole','Lili',150.00,'Lili\'s silk racer-back camisole with side lace detail will make a chic accompaniment to tailored shorts. Add flat pumps and a structured bag for off-duty city days','Red',59,'red_v_cami.png','red_v_cami_full.png',2),(10,'Turquoise Silk Tunic','Opals',170.00,'This brightly coloured silk tunic is a chic pull-on-and-go vacation piece. Wear it with light-brown leather sandals and stacked gold bangles for Balearic boho luxury.','Blue',38,'teal_tunic.png','teal_tunic_full.png',1),(11,'Pure cotton halter top','Lissoni',49.99,'Nothing says cool-weather glamour like a Lissoni creation - and this pretty lightweight halterneck top is the perfect way to work it on vacation. Wear it with cropped denim and bold gold jewelry for destination dressing at its best.','Yellow',98,'yellow_halter.png','yellow_halter_full.png',5),(12,'Printed jersey tunic','Tucci',420.00,'Tucci\'s multicolored abstract-print jersey tunic will add a chic burst of colour to your holiday wardrobe. Keep cool in the summer heat by teaming it with white mini shorts and bead-embellished sandals.','Blue',35,'swirl_top.png','swirl_top_full.png',1),(13,'Cotton tank','Rory',70.00,'This coral cotton tank is an effortlessly cool summer style. Wear it to pep up taupe chinos and stone wooden wedges.','Orange',68,'coral_vest.png','coral_vest_full.png',2),(14,'Jersey and silk blend tank','Suzanna',50.00,'Show your geek chic credentials with this cool urban tank. Slip it on with black skinny jeans and statement black platforms for a downtown look with attitude.','Red',205,'red_geek.png','red_geek_full.png',6),(15,'Striped tunic top','Tenby',190.00,'This striking tunic top combines modern stripes with an undying love for Google. Team with skinny jeans for a chic day ensemble.','Blue',94,'geek_striped.png','geek_striped_full.png',6),(16,'Draped modal top','Kingly',160.00,'A draped scarf detail gives Kingly\'s sheer teal modal tank an elegant evening edge. Complete the look with tailored trousers and statement gold jewellery.','Blue',130,'blue_draped.png','blue_draped_full.png',4),(17,'Cotton geek tee','Ophelia',55.00,'Ophelia updates the classic white cotton tee with super cool geek logo and a scoop neck. Wear this sheer fine-knit basic off duty with cropped skinny pants and dark-brown accessories.','White',420,'white_geek.png','white_geek_full.png',6),(18,'Scoop neck cotton jersey tee','Persephone',50.00,'No capsule wardrobe is complete without a classic fail whale cotton-jersey t-shirt like this one from Persephone. Tuck it into skinny cargo pants and elevate the look with wedges for relaxed downtown cool.','Blue',239,'failwhale_tee.png','failwhale_tee_full.png',6),(19,'Awesome tank','Ichigo',72.00,'Easy-chic basics like Ichigo\'s grey and awesome jersey tank are the cornerstone of every stylish wardrobe. Wear it with track pants and heels for effortless off-duty cool. ','Grey',374,'awesome_vest.png','awesome_vest_full.png',6),(20,'Print silk tunic top','Bennett',580.00,'An eye-catching print makes Bennett\'s blue silk blouse a glamorous cocktail choice. Balance by teaming this luxe style with skinny leather pants and high-as-you-dare heels.','Blue',193,'pattern_tunic.png','pattern_tunic_full.png',1),(21,'HTML5 Cotton tee','Ichigo',135.00,'Ichigo gives a simple white tee a stylish twist with chic HTML5 logo. Tuck this wear-with-anything piece into a neutral skirt, then finish the look with nude pumps and a cross-body bag.','White',145,'html5_tee.png','html5_tee_full.png',6),(22,'Signature silk binary top','Streets',195.00,'Give minimalist cool a twist in this black sheer washed-silk binary detail top. Team it with big shorts and color-pop heels for refined new-season style.','Black',64,'black_binary.png','black_binary_full.png',6),(23,'Printed silk-chiffon top','Lacey',365.00,'Invest in signature Lacey style with this bohemian-inspired multicolored silk-chiffon top. Team this sheer abstract-print piece with linen shorts and carry a rattan clutch to finish the look. ','Pink',356,'colourblock_tunic.png','colourblock_tunic_full.png',1),(24,'Cotton tank','Haruna',80.00,'It\'s easy to make a on-trend color statement with Haruna\'s fuschia cotton tank. Team it with neutral-hued cotton shorts and buckle-embellished wedges for a cool weekend look.','Pink',937,'pink_vest.png','pink_vest_full.png',2);
/*!40000 ALTER TABLE `ftt_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftt_item_size`
--

DROP TABLE IF EXISTS `ftt_item_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftt_item_size` (
  `item_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  PRIMARY KEY (`size_id`,`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftt_item_size`
--

LOCK TABLES `ftt_item_size` WRITE;
/*!40000 ALTER TABLE `ftt_item_size` DISABLE KEYS */;
/*!40000 ALTER TABLE `ftt_item_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftt_order`
--

DROP TABLE IF EXISTS `ftt_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftt_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `card_digits` varchar(4) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`order_id`,`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftt_order`
--

LOCK TABLES `ftt_order` WRITE;
/*!40000 ALTER TABLE `ftt_order` DISABLE KEYS */;
INSERT INTO `ftt_order` VALUES (1,4,'7777'),(2,6,'1111'),(3,7,'1111'),(4,8,'1111'),(5,9,'1111'),(6,10,'5100'),(7,11,''),(8,8,''),(9,9,''),(10,10,''),(11,11,'');
/*!40000 ALTER TABLE `ftt_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftt_order_item`
--

DROP TABLE IF EXISTS `ftt_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftt_order_item` (
  `order_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`item_id`,`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftt_order_item`
--

LOCK TABLES `ftt_order_item` WRITE;
/*!40000 ALTER TABLE `ftt_order_item` DISABLE KEYS */;
INSERT INTO `ftt_order_item` VALUES (0,0,0),(0,1,1),(0,15,1),(0,8,1),(0,11,2),(0,2,3),(4,11,2),(4,2,3),(5,11,2),(5,2,3),(2,18,1),(2,23,1),(3,18,1),(3,23,1),(6,2,1),(7,1,2),(8,2,1),(10,3,1),(11,1,1);
/*!40000 ALTER TABLE `ftt_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftt_size`
--

DROP TABLE IF EXISTS `ftt_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftt_size` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `size` varchar(2) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`size_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftt_size`
--

LOCK TABLES `ftt_size` WRITE;
/*!40000 ALTER TABLE `ftt_size` DISABLE KEYS */;
INSERT INTO `ftt_size` VALUES (5,'XL'),(4,'L'),(3,'M'),(1,'XS'),(2,'S');
/*!40000 ALTER TABLE `ftt_size` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftt_user`
--

DROP TABLE IF EXISTS `ftt_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftt_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) CHARACTER SET latin1 NOT NULL,
  `last_name` varchar(30) CHARACTER SET latin1 NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 NOT NULL,
  `password` char(32) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftt_user`
--

LOCK TABLES `ftt_user` WRITE;
/*!40000 ALTER TABLE `ftt_user` DISABLE KEYS */;
INSERT INTO `ftt_user` VALUES (1,'Rose','Nichols','rose@rosenichols.co.uk','password'),(2,'Joel','Nichols','joel@cbm.com','password'),(3,'Rose','Nichols','rose_nichols@hotmail.com','password'),(4,'Harry','Potter','hpotter@live.com','password'),(5,'Wilfred','Elphick','wilf@elphick.com',''),(6,'Harry','Potter','h.potter@hp.com',''),(7,'Harry','Potter','harry@potters.net',''),(8,'Harry','Potter','h.potter@hotmail.com',''),(9,'Harry','Potter','harry@potter.com',''),(10,'Arkie','Alderton','shhhs',NULL),(11,'','','',NULL);
/*!40000 ALTER TABLE `ftt_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ftt_user_item`
--

DROP TABLE IF EXISTS `ftt_user_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ftt_user_item` (
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`item_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ftt_user_item`
--

LOCK TABLES `ftt_user_item` WRITE;
/*!40000 ALTER TABLE `ftt_user_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `ftt_user_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lt_item`
--

DROP TABLE IF EXISTS `lt_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lt_item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_type` varchar(40) CHARACTER SET latin1 NOT NULL,
  `location_lost` varchar(40) CHARACTER SET latin1 NOT NULL,
  `date_lost` date NOT NULL,
  `circumstances` varchar(255) CHARACTER SET latin1 NOT NULL,
  `description` varchar(255) CHARACTER SET latin1 NOT NULL,
  `colour` varchar(30) CHARACTER SET latin1 NOT NULL,
  `features` varchar(80) CHARACTER SET latin1 NOT NULL,
  `image` varchar(255) CHARACTER SET latin1 NOT NULL,
  `owns` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lt_item`
--

LOCK TABLES `lt_item` WRITE;
/*!40000 ALTER TABLE `lt_item` DISABLE KEYS */;
INSERT INTO `lt_item` VALUES (1,'Stuffed monkey','Newport City centre','2011-03-19','Dropped by my child in town. The last shops we went into were Marks & Spencer and Boots. We were parked in the Market car park','Dark blue body with lighter blue patches on face. Curly tail.','Blue','Left ear has been re-stitched','',15),(2,'Teddy bear','Elswick Park, Newcastle','2011-02-12','Lost somewhere around Elswick park.','Large teddy with floppy arms and legs. Mid-brown with lighter brown belly and face. Black eyes and stitching.','Brown','Small stain on right arm','',NULL),(3,'Beanie horse','Fisher\'s Farm Park, West Sussex','2011-03-02','Lost on a school trip. Possibly left in the cafe or left on the tractor ride.','Light brown with black hoofs and a black mane.','Brown','No tail','',NULL),(4,'Panda bear toy','Cardiff Central train station','2011-02-20','I was rushing with my child to catch the train. The toy must have fallen out of my bag somewhere in the station.','Black and white stuffed panda toy. Well loved. Approx 15cm tall.','Black and white','None','',NULL),(5,'Stuffed rabbit','Truro, Cornwall','2011-01-29','Lost at the end of our holiday in Cornwall. Possibly left somewhere in Carnon Downs Caravan Park.','Dark brown and white.','Brown and white.','Hole at the top of the left ear','',NULL),(6,'Beanie cat toy','Tate art gallery, London','2011-03-16','Lost on a school trip.','Light grey with dark grey stripes. Red TY tag attached to ear.','Grey','S in red pen on the tag.','',NULL),(7,'Stuffed toy','Bristol','2011-03-22','Shopping in town','Fluffy bird','Yellow','Orange beak','',0),(8,'Beanie toy','Bath','2011-03-22','Spending the day siteseeing in Bath, visited the Royal Crescent and Fashion museum','Smallish beanie toy, red tag attached to one ear','Black','None.','',0),(13,'Plastic toy','UWE, Bristol','2011-03-23','My baby dropped the toy during a visit into the University of the West of England, Bristol','Plastic rattle toy red and white','Red','None','',10),(27,'Soft toy','Paignton Zoo','2011-03-22','Lost at the zoo','Lion toy with fluffy man','Yellow brown','None','',24),(29,'Mobile phone toy','Bath town centre','2011-03-21','Lost in Bath at some point during the day','Toy shaped like a mobile phone. Silver buttons that play sounds when you press them.','Black and silver','conspicuous @ symbol','',26),(30,'Plush toy','London Zoo','2011-02-22','Lost a koala soft toy during a trip to London Zoo','A koala toy, very soft and fluffy. Shades of grey with a black nose and eyes.','Grey','Name Lucy is written on the tag attached to one of its feet','  ',27),(31,'Plastic toy','Bristol Zoo','2011-03-09','Lost at some point during the day at a trip to the zoo','Black rabbit toy','Black','None','',28),(32,'Plush toy','Chester Zoo','2011-04-05','Lost at the zoo, possibly left somewhere after we stopped for lunch','Soft giraffe toy purchased at the zoo','Yellow brown','Left in a bag with a notebook and disposable camera','',29);
/*!40000 ALTER TABLE `lt_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lt_owner`
--

DROP TABLE IF EXISTS `lt_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lt_owner` (
  `owner_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(40) CHARACTER SET latin1 NOT NULL,
  `sname` varchar(40) CHARACTER SET latin1 NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=ascii COLLATE=ascii_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lt_owner`
--

LOCK TABLES `lt_owner` WRITE;
/*!40000 ALTER TABLE `lt_owner` DISABLE KEYS */;
INSERT INTO `lt_owner` VALUES (4,'Sarah','Young','sarah.young@gmail.com'),(5,'Barney','Jones','barney.jones@googlemail.com'),(6,'Joe','Bloggs','joseph.bloggs@hotmail.com'),(7,'Austin','Reed','austin@reed.co.uk'),(8,'Elizabeth','Bennett','lizziebennett@gmail.com'),(10,'Jenny','Baker','jenbaker@live.com'),(13,'Ben','Nolan','b_nolan@live.uk'),(15,'Rebecca','Harrison','becky@harrison.net'),(16,'Roland','Myers','roland.myers@live.com'),(24,'Rose','Nichols','rose2.nichols@live.uwe.ac.uk'),(26,'Anthony','Kelly','ant_kelly2@googlemail.com'),(27,'Harrison','Jones','oldharryjones@hotmail.com'),(28,'Tamara','Bagshawe','tam.bagshawe@live.com'),(29,'Kate','Fforde','kate@fforde.com');
/*!40000 ALTER TABLE `lt_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'rosenich_portfolio'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-10-23 12:00:14
